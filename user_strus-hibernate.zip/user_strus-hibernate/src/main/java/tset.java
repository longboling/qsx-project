import online.qsx.model.Page;

public class tset {

	public static void main(String[] args) {
		Page page = new Page();
		
		System.out.println(page.getPageNo());
	}

}
