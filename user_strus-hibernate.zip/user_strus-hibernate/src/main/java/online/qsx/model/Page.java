package online.qsx.model;

public class Page {
	private int pageNo=0;
	private int pageSize=5;
	private int rowCount;
	private int pageCount;
	private int beforThePageNo;
	private int nextPageNo;
	public int getBeforThePageNo() {
		return beforThePageNo;
	}
	public void setBeforThePageNo(int beforThePageNo) {
		this.beforThePageNo = beforThePageNo;
	}
	public int getNextPageNo() {
		return nextPageNo;
	}
	public void setNextPageNo(int nextPageNo) {
		this.nextPageNo = nextPageNo;
	}
	public int getRowCount() {
		return rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public int getPageCount() {
		return pageCount;
	}
	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageSize() {
		return pageSize;
	}
	@Override
	public String toString() {
		return "Page [pageNo=" + pageNo + ", pageSize=" + pageSize + ", rowCount=" + rowCount + ", pageCount="
				+ pageCount + ", beforThePageNo=" + beforThePageNo + ", nextPageNo=" + nextPageNo + "]";
	}
	public Page(int pageNo, int pageSize) {
		super();
		this.pageNo = pageNo;
		this.pageSize = pageSize;
	}
	public Page(int pageNo, int pageSize, int rowCount, int pageCount) {
		super();
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.rowCount = rowCount;
		this.pageCount = pageCount;
	}
	
	public Page(int pageNo, int pageSize, int rowCount, int pageCount, int beforThePageNo, int nextPageNo) {
		super();
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.rowCount = rowCount;
		this.pageCount = pageCount;
		this.beforThePageNo = beforThePageNo;
		this.nextPageNo = nextPageNo;
	}
	public Page() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
}
