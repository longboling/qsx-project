package online.qsx.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ssh_user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="u_id")
	private Long id;
	@Column(name="u_name")
	private String name;
	@Column(name="u_sex")
	private String sex;
	@Column(name="u_email")
	private String email;
	@Column(name="u_createDate")
	private Date createDate;
	@Column(name="u_modifiedDate")
	private Date modifiedDate;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public User(Long id, String name, String sex, String email, Date createDate, Date modifiedDate) {
		super();
		this.id = id;
		this.name = name;
		this.sex = sex;
		this.email = email;
		this.createDate = createDate;
		this.modifiedDate = modifiedDate;
	}
	public User(String name, String sex, String email, Date createDate, Date modifiedDate) {
		super();
		this.name = name;
		this.sex = sex;
		this.email = email;
		this.createDate = createDate;
		this.modifiedDate = modifiedDate;
	}
	public User(Long id) {
		super();
		this.id = id;
	}
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", sex=" + sex + ", email=" + email + ", createDate=" + createDate
				+ ", modifiedDate=" + modifiedDate + "]";
	}
	
}
