package online.qsx.action;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import online.qsx.model.Page;
import online.qsx.model.User;
import online.qsx.service.impl.UserServerImpl;

@Controller(value = "userAction")
public class UserAction {
	@Autowired
	private UserServerImpl userServerImpl;
	
	private List<User> users = new ArrayList<>();
	private User user;
	private Page page = new Page();
	private int countMan;
	private int countWoMan;
	public int getCountMan() {
		return countMan;
	}
	public void setCountMan(int countMan) {
		this.countMan = countMan;
	}
	public int getCountWoMan() {
		return countWoMan;
	}
	public void setCountWoMan(int countWoMan) {
		this.countWoMan = countWoMan;
	}
	public List<User> getUsers() {
		return users;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String querylist(){
		System.out.println(page.getPageNo());
		
		users=userServerImpl.quaryAll(page);
		return "list";
	}
	public String querySex(){
		int[] countSex = userServerImpl.querySex();
		countMan=countSex[0];
		countWoMan=countSex[1];
		return "analyze";
	}
	public String go_add(){
		System.out.println("goadd");
		return "add";
	}
	public String do_add(){
		System.out.println(user.getName());
		
		userServerImpl.do_add(user);
		return querylist();
	}
	public String go_edit(){
		System.out.println("go_edit");
		return "edit";
	}
	public String do_edit(){
		System.out.println("do_edit");
		userServerImpl.do_edit(user);
		return "info";
	}
	public String delete(){
		System.out.println("delete");
		userServerImpl.delete(user);
		users=userServerImpl.quaryAll(page);
		return "list";
	}
	public String info(){
		System.out.println("info");
		user=userServerImpl.info(user);
		return "info";
	}
}
