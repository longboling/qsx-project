package online.qsx.dao.impl;

import java.util.Date;
import java.util.List;

import javax.transaction.Synchronization;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import online.qsx.common.BaseDao;
import online.qsx.model.Page;
import online.qsx.model.User;
@Repository
public class UserDaoImpl {
	@Autowired
	private BaseDao baseDao;
	
	@SuppressWarnings("unchecked")
	public List<User> queryAll(Page page){
		System.out.println("queryAll");
		rowAndPageCount(page);
		int pageNo=page.getPageNo();		
		int pageSize=page.getPageSize();
		page.setNextPageNo(pageNo+pageSize);
		page.setBeforThePageNo(pageNo-pageSize);
		DetachedCriteria criteria=DetachedCriteria.forClass(User.class);
		return (List<User>) baseDao.getHibernateTemplate().findByCriteria(criteria, pageNo, pageSize);
	}
	public int[] querySex(){
		int[] countSex={baseDao.getHibernateTemplate().find("from User u where u.sex=?","man").size(),
		 baseDao.getHibernateTemplate().find("from User u where u.sex=?","woman").size()};
		return countSex;
	}
	public Page rowAndPageCount(Page page){
		List<User> allUser= (List<User>) baseDao.getHibernateTemplate().find("from User");
		int rowCount = allUser.size();
		page.setRowCount(rowCount);
		int temp = rowCount % page.getPageSize();
		if(temp==0){
			page.setPageCount(rowCount/page.getPageSize());
		}else{
			page.setPageCount(rowCount/page.getPageSize()+1);
		}
		System.out.println("总计"+rowCount+"条,"+page.getPageCount()+"页");
		return page;	
	}
	

	public void do_add(User user){
		System.out.println("doadd");
		user.setCreateDate(new Date());
		user.setModifiedDate(new Date());
		baseDao.getHibernateTemplate().save(user);
		
	}
	
	public void do_edit(User user){
		System.out.println("do_edit");
		user.setModifiedDate(new Date());
		baseDao.getHibernateTemplate().saveOrUpdate(user);
	}
	public void delete(User user){
		System.out.println("delete");
		baseDao.getHibernateTemplate().delete(user);
	}
	public User info(User user){
		System.out.println("info");
		
		return baseDao.getHibernateTemplate().get(User.class,user.getId());
	}
}
