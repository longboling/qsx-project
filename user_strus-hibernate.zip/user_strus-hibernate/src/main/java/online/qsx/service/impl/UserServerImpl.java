package online.qsx.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import online.qsx.dao.impl.UserDaoImpl;
import online.qsx.model.Page;
import online.qsx.model.User;
@Service
public class UserServerImpl {
	@Autowired
	private UserDaoImpl userdaoImpl;
	
	public List<User> quaryAll(Page page){
		return userdaoImpl.queryAll(page);
	}
	
	public int[] querySex(){
		return userdaoImpl.querySex();
	}
	public void do_add(User user){
		
		userdaoImpl.do_add(user);
	}
	
	public void do_edit(User user){
		userdaoImpl.do_edit(user);
	}
	
	public void delete(User user){
		userdaoImpl.delete(user);
	}
	
	public User info(User user){
		return userdaoImpl.info(user);
	}
}
